/*
 * zonest.h
 *
 *  Created on: 12 sep. 2020
 *      Author: sasha
 */

#ifndef ZONEST_H_
#define ZONEST_H_

typedef enum{ZONE_1, ZONE_2, ZONE_3, ZONE_OUT}zones_t;

#endif /* ZONEST_H_ */

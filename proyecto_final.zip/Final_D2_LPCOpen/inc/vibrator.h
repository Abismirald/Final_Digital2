#ifndef VIBRATOR_H
#define VIBRATOR_H

#include "zones.h"
#include "zonest.h"
void vibrator_ON(zones_t zone);
void vibrator_OFF();

#endif

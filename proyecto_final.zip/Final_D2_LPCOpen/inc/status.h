/*
 * status.h
 *
 *  Created on: 8 sep. 2020
 *      Author: sasha
 */

#ifndef STATUS_H_
#define STATUS_H_

#include "main.h"

typedef enum{OK_INIT, OK_ZONE, ERROR_ZONE}status_t;

#endif /* STATUS_H_ */

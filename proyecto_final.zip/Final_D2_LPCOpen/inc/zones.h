/*
 * zones.h
 *
 *  Created on: 8 sep. 2020
 *      Author: sasha
 */

#ifndef ZONES_H_
#define ZONES_H_
#include "status.h"
#include "zonest.h"

status_t zone(zones_t ZONE);

#endif /* ZONES_H_ */
